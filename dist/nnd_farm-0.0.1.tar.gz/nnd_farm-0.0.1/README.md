A crud api for Ingrid Farms 
built with Python Flask and SQLite

You can test the api end points in the testing.rest - remember to comment other api call and test one api one at a time if using that file 
To make it easier, use postman.

Distributable package: https://test.pypi.org/project/nnd-farm/0.0.1/
