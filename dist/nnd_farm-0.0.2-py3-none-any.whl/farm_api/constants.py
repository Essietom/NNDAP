from pathlib import Path

PROJECT_ROOT = Path(__file__).parent.parent

INGRID_FARM_DATABASE = "ingrid_farm.db"